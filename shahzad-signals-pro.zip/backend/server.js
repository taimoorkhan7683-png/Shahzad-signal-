// backend/server.js - simple Express server exposing /api/top-signals and health
const express = require('express');
const fetch = require('node-fetch');
const indicators = require('./lib/indicators');
const app = express();
app.use(express.json());

// in-memory cache (simple)
let CACHE = { top: null, updated: 0 };

app.get('/health', (req,res)=> res.json({ ok:true, ts: Date.now() }));

// /api/top-signals returns top signals computed by worker (or fallback sample)
app.get('/api/top-signals', async (req,res)=>{
  if (CACHE.top && (Date.now() - CACHE.updated) < 60000) {
    return res.json({ topList: CACHE.top, generatedAt: new Date(CACHE.updated).toISOString() });
  }
  // Fallback: compute a tiny sample using CoinGecko markets (no API keys required)
  try{
    const cg = await fetch('https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&order=market_cap_desc&per_page=20&page=1&sparkline=false');
    const data = await cg.json();
    const top = [];
    for (let i=0;i<10 && i<data.length;i++){
      const d = data[i];
      // simple heuristic score: 24h change + market_cap rank inverse
      const score = ((d.price_change_percentage_24h || 0)/10) + (1/(i+1));
      top.push({ symbol: d.symbol.toUpperCase(), score: score.toFixed(3), signal: score>0.5? 'BUY':'WAIT', entry: d.current_price.toFixed(6), sl: (d.current_price*0.98).toFixed(6), tp1: (d.current_price*1.03).toFixed(6) });
    }
    CACHE.top = top; CACHE.updated = Date.now();
    return res.json({ topList: top, generatedAt: new Date().toISOString(), note: 'fallback sample (CoinGecko)' });
  }catch(e){
    res.status(500).json({ error: 'failed', details: String(e) });
  }
});

// simple endpoint to accept worker push (worker posts computed signals here)
app.post('/api/push-signals', (req,res)=>{
  try{
    const list = req.body.list || [];
    CACHE.top = list;
    CACHE.updated = Date.now();
    return res.json({ ok:true, count: list.length });
  }catch(err){
    return res.status(500).json({ error: String(err) });
  }
});

const PORT = process.env.PORT || 4000;
app.listen(PORT, ()=> console.log('Backend listening on', PORT));